import scrapy
from scrapy.crawler import CrawlerProcess
import mysql.connector
from datetime import datetime

def main(event, context):
	pswd = "!!stesat39bu2u??"
	page_link = []

	class MySpider(scrapy.Spider):
		name = "Pastebin"
		
		custom_settings = {
			'DOWNLOAD_DELAY': 15,
		}

		def __init__(self, *args, **kwargs):
			super(MySpider, self).__init__(*args, **kwargs) 
			self.pswd=[kwargs.get('pswd')] 
	    
		def start_requests(self):
			i = 0
		
			seed_url = "https://pastebin.com/trends"
			for i in range(4):
				i+1      
				yield scrapy.Request(url=seed_url, callback=self.parse, dont_filter=True)
		
		def parse(self, response):
			def commitSql(page_link_unique):
				try:
					cnx = mysql.connector.connect(host="aintnodatabase.c3hfm1hvxqhx.eu-west-2.rds.amazonaws.com",port=3306,database="pastebin",user="root",password=pswd)
					cursor = cnx.cursor(buffered=True)
					for link in page_link_unique:
						query = "INSERT INTO pastebin (LINK, TIME) VALUES ('"+link+"','"+str(datetime.now())+"')"
						cursor.execute(query)
					cnx.commit()
				except mysql.connector.Error as err:
					print(str(err))
				else:
					cursor.close()
					cnx.close()

			p_link = [response.xpath('//ul/li//@href').extract()]

			new_link = []
			[new_link.append(a.encode('ascii','ignore')) for a in p_link[0]]
			commitSql(list(set(new_link) - set(page_link)))
			[page_link.append(a.encode('ascii','ignore')) for a in p_link[0]][-9:]

	process = CrawlerProcess()
	process.crawl(MySpider, pswd=pswd)
	process.start()
